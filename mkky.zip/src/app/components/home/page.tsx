'use client'
//import ReactDOM from 'react-dom';
//import Display from "./display"
import Input from "./input"

function App() {
 
    return (

      <div>


        <h1 className="text-center font-bold font-serif">PGQL</h1>
        <Input/>      
      </div>
    );
  };
  
  export default App;