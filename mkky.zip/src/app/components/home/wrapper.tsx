// import TableCell from "./display/tableCell";

// import {executeQuery} from './db'

// function Wrapper(props){
//     function submitQuery(tableName, colID, newVal, keyName, rowID){
        
//         const updateQuery = `UPDATE ${tableName} SET ${colID} = ${newVal} WHERE ${keyName} = ${rowID} `
//         return executeQuery(updateQuery)
//         //const updateQuery = `UPDATE ${props.table_name} SET ${props.colID} = ${value} WHERE ${props.keyName} = ${props.rowID} `
        
//     }  
//     return(
//         <TableCell data = {props.data}></TableCell>
//     )
// }
// export default Wrapper;

//onChange={(event) => submitQuery(props.table_name,props.colID,event.target.value, props.keyName, props.rowID)}